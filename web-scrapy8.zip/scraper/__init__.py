from .controlador import ejecutar_scraper
