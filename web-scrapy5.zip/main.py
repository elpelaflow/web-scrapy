from ui.ventana_principal import iniciar_ui

if __name__ == "__main__":
    iniciar_ui()
    